const header = new Headers({
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Origin': '*'
})

const url = new URL('https://sf-pyw.mosyag.in/sse/vote/stats');

const ES = new EventSource(url, header);

// обработка ошибки обращения к серваку
ES.onerror = error => {
	ES.readyState ? console.error("⛔ EventSource failed: ", error) : null;
}

// парсим получаемые ответы от сервера и вытаскиваем оттуда статистику голосования
// за соответствующее животное
ES.onmessage = message =>{
	let data=JSON.parse(message.data);
	let dogs=data.dogs;
	let cats=data.cats;
	let parrots=data.parrots;

	let max=Math.max(dogs,cats,parrots);

	//обращаемся к соответствующим прогресс-барам и помещаем их в переменные
	let bar_cats=document.querySelector("#bar-cats");
	let bar_dogs=document.querySelector("#bar-dogs");
	let bar_parrots=document.querySelector("#bar-parrots");

	//устанавливаем значение width каждого прогресс-бара как долю в процентах 
	// от общего числа голосов
	bar_cats.style.cssText=`width: ${(cats/max)*100}%`;
	bar_dogs.style.cssText=`width: ${(dogs/max)*100}%`;
	bar_parrots.style.cssText=`width: ${(parrots/max)*100}%`;


	//помещаем статистику голосования за каждое животное в соответствующий 
	// прогресс-бар
	bar_cats.textContent =`Кошки набрали ${cats} голосов`;
	bar_dogs.textContent=`Собаки набрали ${dogs} голосов`;
	bar_parrots.textContent=`Попугаи набрали ${parrots} голосов`;

}